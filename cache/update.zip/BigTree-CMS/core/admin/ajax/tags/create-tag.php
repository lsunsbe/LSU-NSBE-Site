<?
	echo $admin->createTag($_POST["tag"]);
?>