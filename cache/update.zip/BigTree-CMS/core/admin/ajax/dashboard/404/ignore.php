<?
	header("Content-type: text/javascript");
	$admin->ignore404($_POST["id"]);
?>