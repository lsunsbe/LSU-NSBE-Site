<?
	header("Content-type: text/javascript");
?>
BigTree.Growl("Error","You have been signed out.");